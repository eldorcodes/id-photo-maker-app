# Image Compressor — Expo 53 (Ads migrated)

- All `expo-ads-admob` references replaced with `react-native-google-mobile-ads`.
- Kept IAP via `expo-in-app-purchases`.
- Interstitial cadence and Rewarded cooldown included.

## Run
npm install
npx expo prebuild
npx expo run:ios   # or: npx expo run:android

## Configure
Set AdMob **App IDs** in app.json plugin (required). Use EXPO_PUBLIC_* env for unit IDs.
