export const COLORS={brand:'#002855',accent:'#2563EB',text:'#222',subtext:'#666',bg:'#fff',card:'#f7f9fc'};
