import * as InAppPurchases from 'expo-in-app-purchases';
import { Alert } from 'react-native';
import { setPremiumFlag } from './premiumFlag';

const PRODUCT_ID=process.env.EXPO_PUBLIC_IAP_REMOVE_ADS_PRODUCT_ID||'imagecompressor_remove_ads';
let connected=false;
export async function initIAP(){
  try{
    await InAppPurchases.connectAsync(); connected=true;
    InAppPurchases.setPurchaseListener(async({responseCode,results})=>{
      if(responseCode===InAppPurchases.IAPResponseCode.OK){
        for(const p of results){
          if(!p.acknowledged){
            await setPremiumFlag(true);
            Alert.alert('Premium Unlocked','Ads removed & Batch compression enabled.');
            await InAppPurchases.finishTransactionAsync(p,true);
          }
        }
      }
    });
  }catch{}
}
export function teardownIAP(){ if(connected) InAppPurchases.disconnectAsync(); }
export async function fetchProducts(){ try{const {responseCode,results}=await InAppPurchases.getProductsAsync([PRODUCT_ID]); if(responseCode===InAppPurchases.IAPResponseCode.OK) return results;}catch{} return []; }
export async function buyRemoveAds(){ try{ await InAppPurchases.purchaseItemAsync(PRODUCT_ID);}catch{} }
export async function restorePurchases(){ try{ const {responseCode,results}=await InAppPurchases.getPurchaseHistoryAsync(false); if(responseCode===InAppPurchases.IAPResponseCode.OK){ const owned=results?.some(p=>p.productId===PRODUCT_ID); if(owned){ await setPremiumFlag(true); return true;} } }catch{} return false; }
