import express from 'express';
import axios from 'axios';
import { GoogleAuth } from 'google-auth-library';

const router = express.Router();

// ---- Apple Receipt Verification ----
// Body: { receipt: string, productId?: string }
router.post('/verify-apple', async (req, res) => {
  try {
    const { receipt } = req.body || {};
    if (!receipt) return res.status(400).json({ valid: false, error: 'missing_receipt' });

    const useSandbox = String(process.env.APPLE_VERIFY_USE_SANDBOX || 'true') === 'true';
    const url = useSandbox
      ? 'https://sandbox.itunes.apple.com/verifyReceipt'
      : 'https://buy.itunes.apple.com/verifyReceipt';

    const body = {
      'receipt-data': receipt,
      'password': process.env.APPLE_SHARED_SECRET || undefined,
      'exclude-old-transactions': true
    };

    const { data } = await axios.post(url, body, { headers: { 'Content-Type': 'application/json' } });
    // status === 0 => valid
    const valid = data && data.status === 0;
    return res.json({ valid, raw: data });
  } catch (e) {
    return res.status(200).json({ valid: false, error: 'apple_verify_failed' });
  }
});

// ---- Google Play Purchase Verification (one-time products) ----
// Body: { purchaseToken: string, productId: string, packageName: string }
router.post('/verify-google', async (req, res) => {
  try {
    const { purchaseToken, productId, packageName } = req.body || {};
    if (!purchaseToken || !productId || !packageName) {
      return res.status(400).json({ valid: false, error: 'missing_params' });
    }

    const b64 = process.env.GOOGLE_SERVICE_ACCOUNT_JSON_BASE64 || '';
    if (!b64) return res.json({ valid: false, error: 'missing_google_credentials' });
    const credentials = JSON.parse(Buffer.from(b64, 'base64').toString('utf8'));

    const auth = new GoogleAuth({
      credentials,
      scopes: ['https://www.googleapis.com/auth/androidpublisher'],
    });
    const client = await auth.getClient();

    // For one-time in-app products use "purchases.products".
    const url = `https://androidpublisher.googleapis.com/androidpublisher/v3/applications/${packageName}/purchases/products/${productId}/tokens/${purchaseToken}`;
    const { data } = await client.request({ url });

    // purchaseState: 0 = Purchased, 1 = Canceled, 2 = Pending (for subscriptions)
    const valid = data && data.purchaseState === 0;
    return res.json({ valid, raw: data });
  } catch (e) {
    return res.status(200).json({ valid: false, error: 'google_verify_failed' });
  }
});

export default router;
