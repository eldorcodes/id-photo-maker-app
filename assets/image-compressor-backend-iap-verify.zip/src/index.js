import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import morgan from 'morgan';
import iapRouter from './routes/iap.js';

const app = express();

const corsOrigin = process.env.CORS_ORIGIN || '*';
app.use(cors({ origin: corsOrigin === '*' ? true : corsOrigin }));
app.use(express.json({ limit: '2mb' }));
app.use(morgan('tiny'));

app.get('/health', (_req, res) => res.json({ ok: true }));
app.use('/iap', iapRouter);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`[backend] listening on :${PORT}`));
