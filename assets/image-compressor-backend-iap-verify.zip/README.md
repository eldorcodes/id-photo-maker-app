# Image Compressor — IAP Verification Backend (Apple + Google)

Minimal, production-ready Node/Express server for verifying **react-native-iap** purchases.

## Endpoints

- **GET /health** → `{ ok: true }`
- **POST /iap/verify-apple**
  - Body: `{ "receipt": "<base64 string>" }`
  - Returns: `{ valid: boolean, raw?: any }`
  - Uses `APPLE_VERIFY_USE_SANDBOX=true` for dev by default.
- **POST /iap/verify-google**
  - Body: `{ "purchaseToken": string, "productId": string, "packageName": string }`
  - Returns: `{ valid: boolean, raw?: any }`
  - Requires a Google **service account** with Android Publisher access.

## Setup

```bash
cp .env.example .env
# Edit .env:
# - APPLE_VERIFY_USE_SANDBOX=true for dev, false for App Store
# - APPLE_SHARED_SECRET only if you use auto-renewable subscriptions
# - GOOGLE_PACKAGE_NAME=com.yourcompany.imagecompressor
# - GOOGLE_SERVICE_ACCOUNT_JSON_BASE64=<base64 of service-account JSON>
npm install
npm run dev
```

### How to create GOOGLE_SERVICE_ACCOUNT_JSON_BASE64

1. In Google Cloud, create a **Service Account** and download the JSON key.
2. Grant it access in Play Console: **API access → Link service account** and give **View financial data** and **Manage orders** (as needed) or at least **View app information** + **View financial data** for verification.
3. Base64-encode the JSON file:
   - macOS/Linux:
     ```bash
     base64 -i ./service-account.json | pbcopy
     ```
   - Windows (PowerShell):
     ```powershell
     [Convert]::ToBase64String([IO.File]::ReadAllBytes("service-account.json")) | Set-Clipboard
     ```
4. Paste into `.env` as `GOOGLE_SERVICE_ACCOUNT_JSON_BASE64`.

## Connect Frontend

Set these env vars in your Expo app (e.g. `.env`):
```
EXPO_PUBLIC_API_URL=http://localhost:4000
EXPO_PUBLIC_ANDROID_PACKAGE_NAME=com.yourcompany.imagecompressor
EXPO_PUBLIC_IAP_REMOVE_ADS_PRODUCT_ID=imagecompressor_remove_ads
```
The app will call:
- `POST /iap/verify-apple` on iOS
- `POST /iap/verify-google` on Android

## Notes

- Keep this server **private** and add rate limits/logging as needed.
- For subscriptions, you should also handle **Real-time Developer Notifications** and receipts accordingly. This sample focuses on **one-time non-consumable** unlocks.
- Always use Google **test cards** and Apple **sandbox** testers during QA.
